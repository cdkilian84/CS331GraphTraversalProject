package edu.cpp.cs331.graphs;

public interface MinimumSpanningTree {
	Graph genMST(Graph g);
}
